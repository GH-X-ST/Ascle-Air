
====================================================================================================
To complete the frontmatter:
- Fill in the title, abstract and name in Cover pages/_Title Info.tex
- Complete the nomenclature Cover pages/_Nomenclature.tex
====================================================================================================

Tips for using LaTeX:

- Use \cref not \ref (\Cref if at the start of a sentence), this will automatically insert the word 'Figure', 'Table', 'Equation' or 'Section'. Also available for ranges using \crefrange.

- References: these are stored in the References.bib file in the BiBTeX format.

- Use the siunitx package for numbers, units and quantities (see examples)

- MATLAB scripts:
Use \lstinputlisting{<filename>.m} 
Note that automatic highlighting of unquoted strings is not supported so enclose the word in ! !
E.g. close !all!

- Tables: best to use the tabularray package as spacing is better and easier to merge cells (see example)